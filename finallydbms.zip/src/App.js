import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Container } from '@mui/material';
import Login from './pages/Login';
import ShopkeeperDashboard from './pages/ShopkeeperDashboard';
import SupplierDashboard from './pages/SupplierDashboard';
import Navbar from './components/common/Navbar';
import Footer from './components/common/Footer';
import { AuthProvider } from './contexts/AuthContext';

const App = () => {
  return (
    <AuthProvider>
      <Navbar />
      <Container component="main" sx={{ mt: 4, mb: 4 }}>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/shopkeeper" element={<ShopkeeperDashboard />} />
          <Route path="/supplier" element={<SupplierDashboard />} />
          <Route path="/" element={<Navigate replace to="/login" />} />
        </Routes>
      </Container>
      <Footer />
    </AuthProvider>
  );
};

export default App;