import React from 'react';
import { AppBar, Toolbar, Typography, Button, Box } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';

const Navbar = () => {
  const { user, logout } = useAuth();

  return (
    <AppBar position="static">
      <Toolbar>
        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
          Smart Inventory
        </Typography>
        {user ? (
          <>
            <Button color="inherit" component={RouterLink} to={user.userType === 'shopkeeper' ? '/shopkeeper' : '/supplier'}>
              Dashboard
            </Button>
            {user.userType === 'shopkeeper' && (
              <Button color="inherit" component={RouterLink} to="/shopkeeper/orders">
                Orders
              </Button>
            )}
            {user.userType === 'supplier' && (
              <Button color="inherit" component={RouterLink} to="/supplier/products">
                Products
              </Button>
            )}
            <Button color="inherit" onClick={logout}>Logout</Button>
          </>
        ) : (
          <Button color="inherit" component={RouterLink} to="/login">Login</Button>
        )}
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;