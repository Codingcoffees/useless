import React from 'react';
import { Box, Container, Typography, Link } from '@mui/material';

const Footer = () => {
  return (
    <Box component="footer" sx={{ bgcolor: 'background.paper', py: 6 }}>
      <Container maxWidth="lg">
        <Typography variant="body2" color="text.secondary" align="center">
          {'Copyright © '}
          <Link color="inherit" href="https://your-website.com/">
            Smart Inventory Management
          </Link>{' '}
          {new Date().getFullYear()}
          {'.'}
        </Typography>
        <Typography variant="body2" color="text.secondary" align="center" sx={{ mt: 1 }}>
          <Link color="inherit" href="/terms">Terms of Service</Link>
          {' | '}
          <Link color="inherit" href="/privacy">Privacy Policy</Link>
          {' | '}
          <Link color="inherit" href="/contact">Contact Us</Link>
        </Typography>
      </Container>
    </Box>
  );
};

export default Footer;