import React, { useState } from 'react';
import { TextField, Button } from '@mui/material';
import Modal from '../common/Modal';
import { createOrder } from '../../utils/api';

const PlaceOrderForm = ({ open, onClose, product }) => {
  const [quantity, setQuantity] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      await createOrder({
        productId: product.id,
        quantity: parseInt(quantity, 10),
        supplierId: product.supplierId,
      });
      onClose();
      // You might want to add some feedback here, like a success message
    } catch (error) {
      console.error('Error placing order:', error);
      // You might want to add some error feedback here
    }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={`Place Order for ${product.name}`}
      actions={
        <Button onClick={handleSubmit} color="primary">
          Place Order
        </Button>
      }
    >
      <form onSubmit={handleSubmit}>
        <TextField
          autoFocus
          margin="dense"
          id="quantity"
          label="Quantity"
          type="number"
          fullWidth
          value={quantity}
          onChange={(e) => setQuantity(e.target.value)}
          required
        />
      </form>
    </Modal>
  );
};

export default PlaceOrderForm;