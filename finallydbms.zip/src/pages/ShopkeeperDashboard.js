import React from 'react';
import { Container } from '@mui/material';
import ShopkeeperDashboard from '../components/shopkeeper/ShopkeeperDashboard';
import { useAuth } from '../contexts/AuthContext';
import { Navigate } from 'react-router-dom';

const ShopkeeperDashboardPage = () => {
  const { user } = useAuth();

  if (!user || user.userType !== 'shopkeeper') {
    return <Navigate to="/login" />;
  }

  return (
    <Container maxWidth="lg">
      <ShopkeeperDashboard />
    </Container>
  );
};

export default ShopkeeperDashboardPage;