import React from 'react';
import { Container } from '@mui/material';
import SupplierDashboard from '../components/supplier/SupplierDashboard';
import { useAuth } from '../contexts/AuthContext';
import { Navigate } from 'react-router-dom';

const SupplierDashboardPage = () => {
  const { user } = useAuth();

  if (!user || user.userType !== 'supplier') {
    return <Navigate to="/login" />;
  }

  return (
    <Container maxWidth="lg">
      <SupplierDashboard />
    </Container>
  );
};

export default SupplierDashboardPage;