import React, { createContext, useState, useContext, useEffect } from 'react';
import { login as authLogin, logout as authLogout, isAuthenticated, getUserType } from '../utils/auth';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    if (isAuthenticated()) {
      setUser({ userType: getUserType() });
    }
  }, []);

  const login = async (username, password, userType) => {
    const result = await authLogin(username, password, userType);
    setUser({ userType: result.userType });
    return result;
  };

  const logout = () => {
    authLogout();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};