// This file contains utility functions for handling authentication

// Simulated token storage
const TOKEN_KEY = 'auth_token';
const USER_TYPE_KEY = 'user_type';

export const setToken = (token) => {
  localStorage.setItem(TOKEN_KEY, token);
};

export const getToken = () => {
  return localStorage.getItem(TOKEN_KEY);
};

export const removeToken = () => {
  localStorage.removeItem(TOKEN_KEY);
};

export const setUserType = (userType) => {
  localStorage.setItem(USER_TYPE_KEY, userType);
};

export const getUserType = () => {
  return localStorage.getItem(USER_TYPE_KEY);
};

export const removeUserType = () => {
  localStorage.removeItem(USER_TYPE_KEY);
};

export const isAuthenticated = () => {
  return !!getToken();
};

// Simulated login function
export const login = async (username, password, userType) => {
  // In a real application, you would make an API call here
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (username && password) {
        const token = 'fake_token_' + Math.random().toString(36).substr(2);
        setToken(token);
        setUserType(userType);
        resolve({ token, userType });
      } else {
        reject(new Error('Invalid credentials'));
      }
    }, 500);
  });
};

export const logout = () => {
  removeToken();
  removeUserType();
};